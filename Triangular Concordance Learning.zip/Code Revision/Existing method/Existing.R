Laplacian1<-function(A,X,K)
{
  D<-colSums(A)
  D_tau<-D+mean(D)
  L<-A
  L<-L/sqrt(D)
  L<-t(t(L)/sqrt(D))
  X_standard<-t(t(X)-colMeans(X))
  X_standard<-t(t(X_standard)/sqrt(colMeans(X_standard^2)))
  
  L2<-L%*%L
  eigen_L2<-eigen(L2)
  lambda_L2<-eigen_L2$values
  XXT<-X_standard%*%t(X_standard)
  eigen_XXT<-eigen(XXT)
  lambda_XXT<-eigen_XXT$values[1:ncol(X)]
  
  alpha_min<-(lambda_L2[K]-lambda_L2[K+1])/lambda_XXT[1]
  if(ncol(X)<=K)
  {alpha_max<-(lambda_L2[1])/lambda_XXT[ncol(X)]}else
  {alpha_max<-(lambda_L2[1])/(lambda_XXT[K-1]-lambda_XXT[K])}
  alpha_candidate<-alpha_min*(0:100/100)+alpha_max*(100:0/100)
  
  cluster_all<-NULL
  withinsum<-NULL
  jishu<-NULL
  
  for (alpha in alpha_candidate) 
  {
    Target<-L+alpha*XXT
    eigen_Target<-eigen(Target)
    U<-eigen_Target$vectors[,1:K]
    kmeansU<-kmeans(U,K,iter.max = 50,nstart = 5)
    cluster_all<-cbind(cluster_all,kmeansU$cluster)
    sumsum<-0
    suan<-NULL
    for(k in 1:K)
    {
      mean_k<-colMeans(t(t(U)[,kmeansU$cluster==k]))
      sumsum<-sumsum+sum((t(U)[,kmeansU$cluster==k]-mean_k)^2)
      suan<-c(suan,sum(kmeansU$cluster==k))
    }
    withinsum<-c(withinsum,sumsum)
    jishu<-cbind(jishu,suan)
  }
  return(list(cluster_all=cluster_all,withinsum=withinsum,jishu=jishu))
}

Laplacian2<-function(A,X,K)
{
  D<-colSums(A)
  D_tau<-D+mean(D)
  L<-A
  L<-L/sqrt(D)
  L<-t(t(L)/sqrt(D))
  X_standard<-t(t(X)-colMeans(X))
  X_standard<-t(t(X_standard)/sqrt(colMeans(X_standard^2)))
  
  L2<-L%*%L
  eigen_L2<-eigen(L2)
  lambda_L2<-eigen_L2$values
  XXT<-X_standard%*%t(X_standard)
  eigen_XXT<-eigen(XXT)
  lambda_XXT<-eigen_XXT$values[1:ncol(X)]
  
  alpha_min<-(lambda_L2[K]-lambda_L2[K+1])/lambda_XXT[1]
  if(ncol(X)<=K)
  {alpha_max<-(lambda_L2[1])/lambda_XXT[ncol(X)]}else
  {alpha_max<-(lambda_L2[1])/(lambda_XXT[K-1]-lambda_XXT[K])}
  alpha_candidate<-alpha_min*(100:0/100)+alpha_max*(0:100/100)
  
  cluster_all<-NULL
  withinsum<-NULL
  jishu<-NULL
  
  for (alpha in alpha_candidate) 
  {
    Target<-L2+alpha*XXT
    eigen_Target<-eigen(Target)
    U<-eigen_Target$vectors[,1:K]
    kmeansU<-kmeans(U,K,iter.max = 50,nstart = 5)
    cluster_all<-cbind(cluster_all,kmeansU$cluster)
    sumsum<-0
    suan<-NULL
    for(k in 1:K)
    {
      mean_k<-colMeans(t(t(U)[,kmeansU$cluster==k]))
      sumsum<-sumsum+sum((t(U)[,kmeansU$cluster==k]-mean_k)^2)
      suan<-c(suan,sum(kmeansU$cluster==k))
    }
    withinsum<-c(withinsum,sumsum)
    jishu<-cbind(jishu,suan)
  }
  return(list(cluster_all=cluster_all,withinsum=withinsum,jishu=jishu))
}

MMSBM<-function(A,K)
{
  # dimension
  n<-nrow(A)
  
  Theta<-matrix(rexp(K*n),nrow = K,ncol = n)
  Theta<-t(Theta)/colSums(Theta)
  
  Omega<-matrix(runif(K^2),K,K)
  Omega<-Omega/sum(Omega)
  Omega<-(Omega+t(Omega))/2
  
  Q<-array(0,dim = c(n,n,K,K))
  P<-((Theta%*%Omega%*%t(Theta))*A+(Theta%*%(1-Omega)%*%t(Theta))*(1-A))*0.999+0.001/2
  
  #A_vector<-A[upper.tri(A)]
  P_vector<-P[upper.tri(P)]
  ll1<-sum(log(P_vector))
  ll0<-ll1-1
  
  while(ll1-ll0>0.1)
  {
    ll0<-ll1
    for(k1 in 1:K)
    {
      for(k2 in 1:K)
      {
        Q[,,k1,k2]<-((Omega[k1,k2]*A+(1-Omega[k1,k2])*(1-A))*(Theta[,k1]%*%t(Theta[,k2]))/P)*0.999+0.001
        All<-sum(Q[,,k1,k2])-sum(diag(Q[,,k1,k2]))
        Omega[k1,k2]<-sum(A*Q[,,k1,k2])/All
      }
    }
    U_theta<-apply(Q,c(1,3),sum)
    for(i in 1:n)
    {
      U_theta[i,]<-(U_theta[i,]-colSums(Q[i,i,,]))/(n-1)
    }
    Theta<-(U_theta)/rowSums(U_theta)
    
    P<-((Theta%*%Omega%*%t(Theta))*A+(Theta%*%(1-Omega)%*%t(Theta))*(1-A))*0.999+0.001/2
    
    #A_vector<-A[upper.tri(A)]
    P_vector<-P[upper.tri(P)]
    ll1<-sum(log(P_vector))
  }
  
  return(list(Omega=Omega,Theta=Theta,log.lik=ll1))
}

GSM<-function(A,X,K)
{
  # dimension
  n<-nrow(X)
  d<-ncol(X)
  Q<-array(0,dim = c(n,n,K,K))
  P<-array(0,dim = c(n,n,K,K))
  
  # Initialization
  S<-matrix(rnorm(K*d),nrow = K,ncol = d)
  Theta<-matrix(rexp(K*n),nrow = K,ncol = n)
  Omega<-matrix(rexp(K^2),K,K)
  
  S<-S-colMeans(S)+1/d
  Theta<-Theta/colSums(Theta)
  Omega<-Omega/sum(Omega)
  Omega<-(Omega+t(Omega))/2
  
  for(k1 in 1:K)
  {
    for(k2 in 1:K)
    {}
  }
}