library(abind)
source("Existing.R")
#set.seed(67)

ALL<-NULL
n<-150
  p<-10
  q<-2
  K<-3
  membership<-c(rep(1,0.4*n),rep(2,0.3*n),rep(3,0.3*n))
  
  B<-t(matrix(c(1,-1,1,0,0,1,1,1,rep(0,12))*1.25,q,p))/2
  #X<-matrix(rnorm(n*p),n,p)
  
  mu<-t(matrix(c(2,0,-4/3,2,-4/3,-2),q,K))
  mu<-mu[membership,]
  
  Result<-NULL
  for(iter in 1:100)
  {
    
    A_original<-matrix(0,n,n)
    
    
    while(min(rowSums(A_original))==0)
    {
      A_original<-matrix(0,n,n)
      X<-matrix(rnorm(n*p),n,p)
      Z<-X%*%B+mu
      #degree_max<-rbinom(n,n-2,0.)+1
      
      dist_Z<-as.matrix(dist(Z,upper = T,diag = T))
      for(i in 1:(n-1))
      {
        for(j in (i+1):n)
        {
          A_original[i,j]<-rbinom(1,1,median(c(0,1,(3-dist_Z[i,j])/2)))
          A_original[j,i]<-A_original[i,j]
          
          #CV_group[i,j]<-sample(1:5,1)
          #CV_group[j,i]<-CV_group[i,j]
          #if(A[i,j]==1)
          #{
          #  segments(Z[i,1],Z[i,2],Z[j,1],Z[j,2],col="grey33")
          #}
        }
      }}
    Total_degree<-sum(A_original)/2
    Degree<-rowSums(A_original)
    To_predict<-floor(Total_degree/5)
    Testing_set<-NULL
    Training_set<-NULL
    All_set<-NULL
    for(i in 1:(n-1))
    {
      for(j in (i+1):n)
      {
        if(A_original[i,j]==1)
        {
          All_set<-rbind(All_set,c(i,j))
        }
      }
    }
    
    i<-0
    while(i<To_predict)
    {if(min(Degree)<=5)
    {
      save_index<-which(Degree<=5)
      link_index1<-which(All_set[,1]%in%save_index)
      link_index2<-which(All_set[,2]%in%save_index)
      link_index<-union(link_index1,link_index2)
      Training_set<-rbind(Training_set,All_set[link_index,])
      All_set<-All_set[-link_index,]
      Degree[save_index]<-Inf
    }
      pick_one<-sample(1:nrow(All_set),1)
      Degree[All_set[pick_one,]]<-Degree[All_set[pick_one,]]-1
      Testing_set<-rbind(Testing_set,All_set[pick_one,])
      All_set<-All_set[-pick_one,]
      i<-i+1
    }
    Training_set<-rbind(Training_set,All_set)
    A<-0*A_original
    for(i in 1:nrow(Training_set))
    {
      A[Training_set[i,1],Training_set[i,2]]<-1
      A[Training_set[i,2],Training_set[i,1]]<-1
    }
    
    MMSB.model<-MMSBM(A,3)
    
    
    
    Pred_all<-(MMSB.model$Theta)%*%(MMSB.model$Omega)%*%t(MMSB.model$Theta)
    A_vector<-A[upper.tri(A)]
    All_vector<-A_original[upper.tri(A_original)]
    Pred_vector<-Pred_all[upper.tri(Pred_all)]
    Truth_all<-All_vector[A_vector==0]
    Pred_all<-Pred_vector[A_vector==0]
    
    n1<-which(Truth_all==1)
    n0<-which(Truth_all==0)
    n_all<-length(Truth_all)
    rank_prediction<-rank(Pred_all)
    Hai<-c(1,0)
    for(i in 1:99)
    {
      indexing<-n_all*i/100
      Hai<-cbind(Hai,c(mean(rank_prediction[n1]>indexing),mean(rank_prediction[n0]<indexing)))
    }
    Hai<-cbind(Hai,c(0,1))
    
    Result<-rbind(Result,Hai)
    
    
    print(c(n,iter))
  }
  
  
write.table(round(Result,2),"MMSBM_P150.txt",sep="&")
write.csv(round(Result,4),"MMSBM_P150.csv")
