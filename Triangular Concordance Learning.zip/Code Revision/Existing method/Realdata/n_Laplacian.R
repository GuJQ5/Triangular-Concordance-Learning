library(abind)
source("Existing.R")
#set.seed(67)

ALL<-NULL
for(n in c(60,100,150))
{
p<-10
q<-2
K<-3
membership<-c(rep(1,0.4*n),rep(2,0.3*n),rep(3,0.3*n))

B<-t(matrix(c(1,-1,1,0,0,1,1,1,rep(0,12))*1.25,q,p))/2
#X<-matrix(rnorm(n*p),n,p)

mu<-t(matrix(c(2,0,-4/3,2,-4/3,-2),q,K))
mu<-mu[membership,]

Result<-NULL
for(iter in 1:100)
{
  
  A<-matrix(0,n,n)
  
  
  while(min(rowSums(A))==0)
  {
    A<-matrix(0,n,n)
    X<-matrix(rnorm(n*p),n,p)
    Z<-X%*%B+mu
    #degree_max<-rbinom(n,n-2,0.)+1
    
    dist_Z<-as.matrix(dist(Z,upper = T,diag = T))
    for(i in 1:(n-1))
  {
    for(j in (i+1):n)
    {
      A[i,j]<-rbinom(1,1,median(c(0,1,(3-dist_Z[i,j])/2)))
      A[j,i]<-A[i,j]
      
      #CV_group[i,j]<-sample(1:5,1)
      #CV_group[j,i]<-CV_group[i,j]
      #if(A[i,j]==1)
      #{
      #  segments(Z[i,1],Z[i,2],Z[j,1],Z[j,2],col="grey33")
      #}
    }
  }}
  
  
  
  OJBK<-Laplacian1(A,X,3)
  
  
  OJBK2<-Laplacian2(A,X,3)
  Result<-rbind(Result,OJBK$cluster_all[,which.min(OJBK$withinsum)],OJBK2$cluster_all[,which.min(OJBK2$withinsum)])
  
  
  print(c(n,iter))
}

True_group<-diag(1,n)
for(i in 1:3)
{
  True_group[membership==i,membership==i]<-1
}
RI_hat<-NULL
TPR_hat<-NULL
TNR_hat<-NULL
RI_hat2<-NULL
TPR_hat2<-NULL
TNR_hat2<-NULL
infer_group<-matrix(0,n,n)
infer_group2<-matrix(0,n,n)
for(i in 1:100)
{
  inf_group<-(Result[1+2*i-2,]%*%t(rep(1,n))==t(Result[1+2*i-2,]%*%t(rep(1,n))))
  inf_group2<-(Result[2+2*i-2,]%*%t(rep(1,n))==t(Result[2+2*i-2,]%*%t(rep(1,n))))
  
  
  TP<-(sum(inf_group*True_group)-n)/2
  TN<-(sum((1-inf_group)*(1-True_group)))/2
  FP<-(sum((inf_group)*(1-True_group)))/2
  FN<-(sum((1-inf_group)*(True_group)))/2
  RI_hat<-c(RI_hat,(TP+TN)/(TP+TN+FP+FN))
  TPR_hat<-c(TPR_hat,(TP)/(TP+FN))
  TNR_hat<-c(TNR_hat,(TN)/(TN+FP))
  
  TP2<-(sum(inf_group2*True_group)-n)/2
  TN2<-(sum((1-inf_group2)*(1-True_group)))/2
  FP2<-(sum((inf_group2)*(1-True_group)))/2
  FN2<-(sum((1-inf_group2)*(True_group)))/2
  RI_hat2<-c(RI_hat2,(TP2+TN2)/(TP2+TN2+FP2+FN2))
  TPR_hat2<-c(TPR_hat2,(TP2)/(TP2+FN2))
  TNR_hat2<-c(TNR_hat2,(TN2)/(TN2+FP2))
  
  infer_group<-infer_group+inf_group
  infer_group2<-infer_group2+inf_group2
}

ALL<-rbind(ALL,c(n,mean(RI_hat),sd(RI_hat),mean(TPR_hat),sd(TPR_hat),mean(TNR_hat),sd(TNR_hat)))
ALL<-rbind(ALL,c(n,mean(RI_hat2),sd(RI_hat2),mean(TPR_hat2),sd(TPR_hat2),mean(TNR_hat2),sd(TNR_hat2)))
}
write.table(round(ALL,2),"Laplacian_n.txt",sep="&")
