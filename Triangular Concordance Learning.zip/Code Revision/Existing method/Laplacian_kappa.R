library(abind)
source("Existing.R")
#set.seed(67)

ALL<-NULL
for(kappa in c(0.8,1.00,1.20))
{
  n<-100
  p<-10
  q<-2
  K<-3
  membership<-c(rep(1,0.4*n),rep(2,0.3*n),rep(3,0.3*n))
  
  B<-t(matrix(c(1,-1,1,0,0,1,1,1,rep(0,12))*1.25,q,p))/2
  #X<-matrix(rnorm(n*p),n,p)
  
  mu<-t(matrix(c(2,0,-4/3,2,-4/3,-2),q,K))*kappa
  mu<-mu[membership,]
  
  Result2<-NULL
  Result3<-NULL
  Result4<-NULL
  for(iter in 1:100)
  {
    
    A<-matrix(0,n,n)
    
    
    while(min(rowSums(A))==0)
    {
      A<-matrix(0,n,n)
      X<-matrix(rnorm(n*p),n,p)
      Z<-X%*%B+mu
      #degree_max<-rbinom(n,n-2,0.)+1
      
      dist_Z<-as.matrix(dist(Z,upper = T,diag = T))
      for(i in 1:(n-1))
      {
        for(j in (i+1):n)
        {
          A[i,j]<-rbinom(1,1,median(c(0,1,(3-dist_Z[i,j])/2)))
          A[j,i]<-A[i,j]
          
          #CV_group[i,j]<-sample(1:5,1)
          #CV_group[j,i]<-CV_group[i,j]
          #if(A[i,j]==1)
          #{
          #  segments(Z[i,1],Z[i,2],Z[j,1],Z[j,2],col="grey33")
          #}
        }
      }}
    
    
    
    OJBK2<-Laplacian2(A,X,2)
    OJBK3<-Laplacian2(A,X,3)
    OJBK4<-Laplacian2(A,X,4)
    Result2<-rbind(Result2,OJBK2$cluster_all[,which.min(OJBK2$withinsum)])
    Result3<-rbind(Result3,OJBK3$cluster_all[,which.min(OJBK3$withinsum)])
    Result4<-rbind(Result4,OJBK4$cluster_all[,which.min(OJBK4$withinsum)])
    
    
    print(c(kappa,iter))
  }
  
  RI_hat<-NULL
  ARI_hat<-NULL
  TPR_hat<-NULL
  TNR_hat<-NULL
  infer_group<-matrix(0,n,n)
  for(i in 1:100)
  {
    inf_group<-(Result2[i,]%*%t(rep(1,n))==t(Result2[i,]%*%t(rep(1,n))))
    TP<-(sum(inf_group*True_group)-n)/2
    TN<-(sum((1-inf_group)*(1-True_group)))/2
    FP<-(sum((inf_group)*(1-True_group)))/2
    FN<-(sum((1-inf_group)*(True_group)))/2
    
    RI_hat<-c(RI_hat,(TP+TN)/(TP+TN+FP+FN))
    TPR_hat<-c(TPR_hat,(TP)/(TP+FN))
    TNR_hat<-c(TNR_hat,(TN)/(TN+FP))
    
    MM<-table(factor(Result2[i,]),factor(membership))
    row_MM<-rowSums(MM)
    col_MM<-colSums(MM)
    
    Enumerator<-sum(choose(as.vector(MM),2))-sum(choose(row_MM,2))*sum(choose(col_MM,2))/choose(n,2)
    Denominator<-0.5*(sum(choose(row_MM,2))+sum(choose(col_MM,2)))-sum(choose(row_MM,2))*sum(choose(col_MM,2))/choose(n,2)
    
    ARI_hat<-c(ARI_hat,Enumerator/Denominator)
    infer_group<-infer_group+inf_group
  }
  ALL<-rbind(ALL,c(kappa,2,mean(RI_hat),sd(RI_hat),mean(ARI_hat),sd(ARI_hat),mean(TPR_hat),sd(TPR_hat),mean(TNR_hat),sd(TNR_hat)))
  
  RI_hat<-NULL
  ARI_hat<-NULL
  TPR_hat<-NULL
  TNR_hat<-NULL
  infer_group<-matrix(0,n,n)
  for(i in 1:100)
  {
    inf_group<-(Result3[i,]%*%t(rep(1,n))==t(Result3[i,]%*%t(rep(1,n))))
    TP<-(sum(inf_group*True_group)-n)/2
    TN<-(sum((1-inf_group)*(1-True_group)))/2
    FP<-(sum((inf_group)*(1-True_group)))/2
    FN<-(sum((1-inf_group)*(True_group)))/2
    
    RI_hat<-c(RI_hat,(TP+TN)/(TP+TN+FP+FN))
    TPR_hat<-c(TPR_hat,(TP)/(TP+FN))
    TNR_hat<-c(TNR_hat,(TN)/(TN+FP))
    
    MM<-table(factor(Result3[i,]),factor(membership))
    row_MM<-rowSums(MM)
    col_MM<-colSums(MM)
    
    Enumerator<-sum(choose(as.vector(MM),2))-sum(choose(row_MM,2))*sum(choose(col_MM,2))/choose(n,2)
    Denominator<-0.5*(sum(choose(row_MM,2))+sum(choose(col_MM,2)))-sum(choose(row_MM,2))*sum(choose(col_MM,2))/choose(n,2)
    
    ARI_hat<-c(ARI_hat,Enumerator/Denominator)
    infer_group<-infer_group+inf_group
  }
  ALL<-rbind(ALL,c(kappa,3,mean(RI_hat),sd(RI_hat),mean(ARI_hat),sd(ARI_hat),mean(TPR_hat),sd(TPR_hat),mean(TNR_hat),sd(TNR_hat)))
  
  RI_hat<-NULL
  ARI_hat<-NULL
  TPR_hat<-NULL
  TNR_hat<-NULL
  infer_group<-matrix(0,n,n)
  for(i in 1:100)
  {
    inf_group<-(Result4[i,]%*%t(rep(1,n))==t(Result4[i,]%*%t(rep(1,n))))
    TP<-(sum(inf_group*True_group)-n)/2
    TN<-(sum((1-inf_group)*(1-True_group)))/2
    FP<-(sum((inf_group)*(1-True_group)))/2
    FN<-(sum((1-inf_group)*(True_group)))/2
    
    RI_hat<-c(RI_hat,(TP+TN)/(TP+TN+FP+FN))
    TPR_hat<-c(TPR_hat,(TP)/(TP+FN))
    TNR_hat<-c(TNR_hat,(TN)/(TN+FP))
    
    MM<-table(factor(Result4[i,]),factor(membership))
    row_MM<-rowSums(MM)
    col_MM<-colSums(MM)
    
    Enumerator<-sum(choose(as.vector(MM),2))-sum(choose(row_MM,2))*sum(choose(col_MM,2))/choose(n,2)
    Denominator<-0.5*(sum(choose(row_MM,2))+sum(choose(col_MM,2)))-sum(choose(row_MM,2))*sum(choose(col_MM,2))/choose(n,2)
    
    ARI_hat<-c(ARI_hat,Enumerator/Denominator)
    infer_group<-infer_group+inf_group
  }
  ALL<-rbind(ALL,c(kappa,4,mean(RI_hat),sd(RI_hat),mean(ARI_hat),sd(ARI_hat),mean(TPR_hat),sd(TPR_hat),mean(TNR_hat),sd(TNR_hat)))
}
write.table(round(ALL[c(1,4,7,2,5,8,3,6,9),],2),"Laplacian_kappa.txt",sep="&")
